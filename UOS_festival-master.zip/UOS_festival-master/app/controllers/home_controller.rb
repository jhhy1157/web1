class HomeController < ApplicationController
  def festival
  end
  
  def index
  end
  
  def schedule
  end
  
  def booth
  end
  
  def lineup
  end
  
  def event
  end
  
  def developer
  end
  
  def foodtruck
  end

end
